from django.contrib import admin
from . models import JSProfile,EmProfile

# Register your models here.
admin.site.register(JSProfile)
admin.site.register(EmProfile)