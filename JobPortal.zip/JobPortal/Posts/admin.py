from django.contrib import admin
from .models import Post,JobApplication

# Register your models here.
admin.site.register(Post)
admin.site.register(JobApplication)
